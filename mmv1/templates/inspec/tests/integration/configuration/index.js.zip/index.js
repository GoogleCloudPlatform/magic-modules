exports.hello = function hello (req, res) {
	res.send('Hello World!')
}