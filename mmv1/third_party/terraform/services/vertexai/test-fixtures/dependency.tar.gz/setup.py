from setuptools import setup

setup(
    name='my-test-package',
    version='0.1',
)
